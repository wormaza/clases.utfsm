package Ejemplo1;

import java.io.IOException;

import javax.management.RuntimeErrorException;

public class Calculadora {
    public float Raiz_n(int a,int n){
        return (float) Math.pow(a, 1 / n);
    }

    //Dado que ha forzado a lanzar IOException debemos indicarlo
    public float Raiz_n2(int a,int n) throws IOException{
        if(n==0)
            throw new IOException();
        return (float) Math.pow(a, 1 / n);
    }

    //Si se maneja dentro del metodo, no es necesario indicar (se manejo internamente)
    public float Raiz_n3(int a,int n){
        try{
            if(n==0)
                throw new IOException();
        }catch(IOException e){
            n = 0;
        }
        
        //No es necesario indicar que se lanzará
        if(n==0){
            throw new RuntimeException();
        }
        return (float) Math.pow(a, 1 / n);
    }

    public float Raiz_n4(int a,int n){
        if(n==0)
            throw new ErrorEjemplo("n es 0");
        return (float) Math.pow(a, 1 / n);
    }

}


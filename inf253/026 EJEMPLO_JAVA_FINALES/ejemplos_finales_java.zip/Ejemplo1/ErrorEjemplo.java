package Ejemplo1;

public class ErrorEjemplo extends RuntimeException {
    public ErrorEjemplo(){}

    public ErrorEjemplo(String texto){super(texto);}
}

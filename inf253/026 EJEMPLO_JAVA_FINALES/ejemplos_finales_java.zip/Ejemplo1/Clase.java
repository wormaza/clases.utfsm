package Ejemplo1;

public class Clase implements Cloneable {
    public int x = 0;
    public Clase(int x){
        this.x = x;
    }

    public Clase clone() {
        try {
            Clase cl = (Clase) super.clone();
            return cl;
        } catch (CloneNotSupportedException e) {
            throw new RuntimeException("Error..", e);
        }
    }
}

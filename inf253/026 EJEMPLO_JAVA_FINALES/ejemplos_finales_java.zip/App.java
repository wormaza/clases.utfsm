import java.io.IOException;

import javax.management.RuntimeErrorException;

import Ejemplo1.Calculadora;
import Ejemplo1.Clase;
import Ejemplo1.ErrorEjemplo;
import Figuras.Circulo;
import Figuras.Cuadrado;
import Figuras.Imprimidor;
import Figuras.Triangulo;

public class App {
    public static void main(String[] args) throws Exception {
        //#region EJEMPLO EQUALS
        String s1 = new String("Ejemplo");
        String s2 = s1;
        String s3 = new String("Ejemplo");

        System.out.println("s1 vs s2:");
        if(s1 == s2)
            System.out.println("\t Referencias");
        if(s1.equals(s2))
            System.out.println("\t Instancias");
        
        System.out.println("s1 vs s3:");
        if(s1 == s3)
            System.out.println("\t Referencias");
        if(s1.equals(s3))
            System.out.println("\t Instancias");
        //#endregion

        //#region EJEMPLO CLONE
        Clase c1 = new Clase(10);
        Clase c2 = c1;
        Clase c3 = c1.clone();

        System.out.println("pre c1: " + c1.x);
        System.out.println("pre c2: " + c2.x);
        System.out.println("pre c3: " + c3.x);
        c1.x = 1000000;
        System.out.println("post c1: " + c1.x);
        System.out.println("post c2: " + c2.x);
        System.out.println("post c3: " + c3.x);
        //#endregion

        //#region INTERFACES
        Cuadrado c = new Cuadrado(10);
        Triangulo t = new Triangulo(10, 10, 10);
        Circulo ci = new Circulo(10);
        Imprimidor.Imprime(c);
        Imprimidor.Imprime(t);
        Imprimidor.Imprime(ci);
        //#endregion
    
        Calculadora calculadora = new Calculadora();
        System.out.println("-->" + calculadora.Raiz_n(4, 2));
        //System.out.println("-->" + calculadora.Raiz_n(4, 0));

        try{
            System.out.println("-->" + calculadora.Raiz_n(4, 0));
        }catch(RuntimeException e){
            ;
            //System.out.println("--> " + e.getMessage());
        }

        //calculadora.Raiz_n2(0, 0);
        //calculadora.Raiz_n3(0, 0);

        try{
            calculadora.Raiz_n4(0, 0);
        }catch(ErrorEjemplo e){
            System.out.println("Problema: " + e.getMessage());
        }


        try{
            calculadora.Raiz_n4(0, 0);
        }catch(ExceptionInInitializerError e){
            System.out.println("Problema 2.1: " + e.getMessage());
        }catch(ErrorEjemplo e){
            System.out.println("Problema 2.2: " + e.getMessage());
        }finally{
            System.out.println("se termino 2");
        }

        try{
            calculadora.Raiz_n4(4, 2);
        }catch(ExceptionInInitializerError e){
            System.out.println("Problema 3.1: " + e.getMessage());
        }catch(ErrorEjemplo e){
            System.out.println("Problema 3.2: " + e.getMessage());
        }finally{
            System.out.println("se termino 3");
        }

        System.out.println("** FIN **");
        
    }
}

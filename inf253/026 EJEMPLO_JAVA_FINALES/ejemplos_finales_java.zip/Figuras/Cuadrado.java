package Figuras;

public class Cuadrado extends Figura{
    protected final int num = 4;
    protected int[] lado = new int[num];
    public Cuadrado(int a){
        this.lado[0] = a;
        this.lado[1] = a;
        this.lado[2] = a;
        this.lado[3] = a;
    }

    @Override
    public double Area(){
        return Math.pow(this.lado[0], 2);
    }

    @Override
    public double Perimetro(){
        return 4*this.lado[0];
    }

    public void SetLado(int lado){
        this.lado[0] = lado;
        this.lado[1] = lado;
        this.lado[2] = lado;
        this.lado[3] = lado;        
    }
}

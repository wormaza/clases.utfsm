package Figuras;

public class Triangulo extends Figura{
    protected final int num = 3;
    protected int[] lado = new int[num];
    public Triangulo(int a, int b, int c){
        this.lado[0] = a;
        this.lado[1] = b;
        this.lado[2] = c;
    }

    @Override
    public double Area(){
        double s = this.Perimetro() / 2;
        double preA = s*(s - this.lado[0])*(s - this.lado[1])*(s - this.lado[2]);
        return Math.sqrt(preA);
    }

    @Override
    public double Perimetro(){
        return this.lado[0] + this.lado[1] + this.lado[2];
    }

    public void SetLado(int lado, int indice){
        this.lado[indice] = lado;
    }
}

package Figuras;

public interface IFigura {
    double PI = 3.1416; //public static final
    double Area();//public abstract
    double Perimetro();//public abstract
}

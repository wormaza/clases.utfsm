package Figuras;

public abstract class Figura implements IFigura{
    protected String color;
    void SetColor(String color){
        this.color = color;
    }

    String GetColor(){
        return this.color;
    }

}

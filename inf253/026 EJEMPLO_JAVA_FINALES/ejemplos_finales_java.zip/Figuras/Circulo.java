package Figuras;

public class Circulo implements IFigura{
    protected double radio = 0;
    public Circulo(double r){
        this.radio = r;
    }

    @Override
    public double Area(){
        return PI*Math.pow(this.radio, 2);
    }

    @Override
    public double Perimetro(){
        return 2*PI*this.radio;
    }
}

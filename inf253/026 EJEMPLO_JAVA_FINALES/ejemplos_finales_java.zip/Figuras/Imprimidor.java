package Figuras;

public class Imprimidor {
    public static void Imprime(IFigura f){
        System.out.println("Perimetro: " + f.Perimetro() + "; Area: " + f.Area());
    }
}

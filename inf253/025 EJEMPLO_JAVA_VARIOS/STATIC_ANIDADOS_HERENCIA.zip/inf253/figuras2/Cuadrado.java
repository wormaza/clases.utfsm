package inf253.figuras2;

public class Cuadrado extends Figura{
    public int lado;
    public Cuadrado(int lado, String color){
     super();
     this.Nombre = "Cuadrado";
     this.lado = lado;
     this.color = color;   
    }
    
    @Override //aunque se puede omitir, se asegura que se este sobre escribiendo un metodo de la super clase
    public double Area(){
        return Math.pow(this.lado, 2);
    }

    public double Perimetro(){
        return 4*this.lado;
    }

    public void SetLado(int lado){
        this.lado = lado;
    }    

}

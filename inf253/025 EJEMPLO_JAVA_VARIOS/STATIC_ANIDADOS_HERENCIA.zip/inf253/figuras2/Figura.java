package inf253.figuras2;
import java.lang.Math;

public class Figura {
    protected String color;
    protected String Nombre = "Figura";
    
    public Figura(int lado, String color){
        System.out.println("Paso por figura!");
        this.Nombre = "Cuadrado";
        this.color = color;   
       }
    
    public Figura(){
        this.color = "Negro";
    }
    
    public void SetColor(String color){
        this.color = color;
    }

    public String GetColor(){
        return this.color;
    }

    protected double Area(){
        return 0;
    }

    protected double Perimetro(){
        return 0;
    }
}

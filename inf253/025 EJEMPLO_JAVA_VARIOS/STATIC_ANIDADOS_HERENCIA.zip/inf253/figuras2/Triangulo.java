package inf253.figuras2;

public class Triangulo extends Figura{
    protected int[] lado = new int[3];
    protected final String Nombre = "Triangulo";
    public Triangulo(int lado1, int lado2, int lado3, String color){
        super();
        String revisar = super.Nombre;
        this.lado[0] = lado1;
        this.lado[1] = lado2;
        this.lado[2] = lado3;
        this.color = color;
    }

    @Override
    public double Area(){
        double s = this.Perimetro() / 2;
        double preA = s*(s - this.lado[0])*(s - this.lado[1])*(s - this.lado[2]);
        return Math.sqrt(preA);
    }

    @Override
    public double Perimetro(){
        return this.lado[0] + this.lado[1] + this.lado[2];
    }

    public void SetLado(int lado, int indice){
        this.lado[indice] = lado;
    }
}

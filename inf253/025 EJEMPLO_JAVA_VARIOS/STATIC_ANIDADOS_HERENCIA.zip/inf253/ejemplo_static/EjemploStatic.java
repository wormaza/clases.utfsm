package inf253.ejemplo_static;

public class EjemploStatic {
    //Static
    static int[] Numeros;
    public static int[] NumeroPublicos;
    public static final int Total = 5;
    static{
        Numeros = new int[5];
        NumeroPublicos = new int[5];
        for(int i = 0; i< 5; i++){
            Numeros[i] = i*i;
            NumeroPublicos[i] = i;
        }
    }

    public static void Imprimidor(){
        String val = "";
        for(int i = 0; i< 5; i++){
            val = val + " " + String.valueOf(Numeros[i]) +"-"+ String.valueOf(NumeroPublicos[i])
            + ";";
        }
        System.out.println("("+Total+")->"+val);
    }

    //No estatico
    int[] NumerosNoEstatico;
    public int[] NumeroPublicosNoEstatico;
    public final int TotalNoEstatico = 5;
    public EjemploStatic(){
        NumerosNoEstatico = new int[5];
        NumeroPublicosNoEstatico = new int[5];
        for(int i = 0; i< 5; i++){
            NumerosNoEstatico[i] = i*i;
            NumeroPublicosNoEstatico[i] = i;
        }
    }
    public void ImprimidorNoEstatico(){
        String val = "";
        for(int i = 0; i< 5; i++){
            val = val + " " + String.valueOf(NumerosNoEstatico[i]) +"-"
            + String.valueOf(NumeroPublicosNoEstatico[i])
            + ";";
        }
        System.out.println("("+TotalNoEstatico+")~>"+val);
    }
}

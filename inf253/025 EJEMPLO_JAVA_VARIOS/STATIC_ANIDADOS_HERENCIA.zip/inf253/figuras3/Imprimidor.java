package inf253.figuras3;

public class Imprimidor {
    public static void Imprime(Figura f){
        System.out.println(f.Nombre +" "+f.GetColor()+" de area: " + f.Area() + " de perimetro " + f.Perimetro());
    }
}

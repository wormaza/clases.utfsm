package inf253.figuras3;
import java.lang.Math;

abstract public class Figura {
    protected String color;
    protected String Nombre = "Figura";
    
    public Figura(int lado, String color){
        System.out.println("Paso por figura!");
        this.Nombre = "Cuadrado";
        this.color = color;   
       }
    
    public Figura(){
        this.color = "Negro";
    }
    
    public void SetColor(String color){
        this.color = color;
    }

    public String GetColor(){
        return this.color;
    }

    abstract protected double Area();

    abstract protected double Perimetro();
}

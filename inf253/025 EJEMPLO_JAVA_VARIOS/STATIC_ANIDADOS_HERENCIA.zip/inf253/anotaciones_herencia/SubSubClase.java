package inf253.anotaciones_herencia;

public class SubSubClase extends SubClase{
    public SubSubClase(){
        System.out.println("~~> Desde SubSubClase sin argumentos");
    }

    public SubSubClase(int x){
        System.out.println("~~> Desde SubSubClase con argumentos");
    }
}

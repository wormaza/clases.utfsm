package inf253.anotaciones_herencia;

public class SubClase extends SuperClase {
    public String nombre = "SubClase";
    public SubClase(){
        System.out.println("~> Constructor sin argumentos SubClase");
    }

    public SubClase(int i){
        System.out.println("~> Constructor con argumentos SubClase");
    }
    
    @Override
    public void Saludador(){
        System.out.println("~> Desde " + this.nombre);
    }

    @Override
    public int Suma(){
        return 2 + 2;
    }

    @Override
    public void Secreto(){
        System.out.println("~> Redefinir secreto de SuperClase");
        super.Secreto();//e igual puedo llamar comportamiento del padre
    }

    public int SuperSUma(){
        return super.Suma();
    }

    public void SuperSaludador(){
        System.out.println("~> Desde " + super.nombre);
    }
}

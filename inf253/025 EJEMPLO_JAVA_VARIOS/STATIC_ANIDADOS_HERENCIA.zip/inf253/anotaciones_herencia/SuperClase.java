package inf253.anotaciones_herencia;

public class SuperClase {
    public String nombre = "SuperClase";
    public SuperClase(){
        System.out.println("-> Constructor sin argumentos SuperClase");
    }

    public SuperClase(int i){
        System.out.println("-> Constructor con argumentos SuperClase");
    }

    public void Saludador(){
        System.out.println("-> Desde " + this.nombre);
    }

    public int Suma(){
        return 1 + 1;
    }

    protected void Secreto(){
        System.out.println("-> Secreto de SuperClase");
    }
}

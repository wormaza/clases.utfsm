package inf253.anidado;

public class Recta {
    protected Punto p1;
    protected Punto p2;
    private String color;

    Recta(int x1,int x2, int y1, int y2){
        p1 = new Punto(x1,y1);
        p2 = new Punto(x2, y2);
    }

    public Recta(int x,int y, String color){
        this(0,x,0,y);
        this.color = color;
    }

    public float M(){
        return 0;
    }

    public float b(){
        return 0;
    }

    public String GetColorP1(){
        return p1.GetColor();
    }

    class Punto{
        private int x;
        private int y;
        Punto(int x, int y){
            this.x = x;
            this.y = y;
        }
        String GetColor(){
            return color;
        }
    }

    public class Punto2{
        //se podrá ver?
    }
}

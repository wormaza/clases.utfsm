package inf253.figuras;

public class Imprimidor {
    public static void Imprime(Cuadrado c){
        System.out.println("Cuadrado "+c.GetColor()+" de area: " + c.Area() + " de perimetro " + c.Perimetro());
    }

    public static void Imprime(Triangulo t){
        System.out.println("Triangulo "+t.GetColor()+" de area: " + t.Area() + " de perimetro " + t.Perimetro());
    }
}

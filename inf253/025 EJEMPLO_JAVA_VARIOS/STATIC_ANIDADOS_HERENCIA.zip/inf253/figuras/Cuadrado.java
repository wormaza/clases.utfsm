package inf253.figuras;
import java.lang.Math;

public class Cuadrado {
    protected int lado;
    protected String color;
    Cuadrado(){
        this.lado = 5;
        this.color = "Negro";
    }
    public Cuadrado(int lado, String color){
        this.lado = lado;
        this.color = color;
    }
    public double Area(){
        return Math.pow(this.lado, 2);
    }

    public double Perimetro(){
        return this.lado * 4;
    }

    public String GetColor(){
        return this.color;
    }

    public int GetLado(){
        return this.lado;
    }

    public void SetColor(String color){
        this.color = color;
    }

    public void SetLado(int lado){
        this.lado = lado;
    }
}

import inf253.ejemplo_static.*;
import inf253.figuras.Cuadrado;
import inf253.figuras.Triangulo;
import inf253.anidado.*;
import inf253.anotaciones_herencia.*;

public class App {
    public static void main(String[] args) throws Exception {
        //#region USO E IMPACTO STATIC
        EjemploStatic.Imprimidor();
        EjemploStatic.NumeroPublicos[0] = 100;
        //EjemploStatic.Total = -1; //lo static se puede modificar, NO lo final
        EjemploStatic.Imprimidor();

        EjemploStatic.NumeroPublicos[0] = -100;
        EjemploStatic e1 = new EjemploStatic();
        //e1.TotalNoEstatico = 10;//parte de la instancia y no puede cambiar. final!
        e1.Imprimidor();//warning, pero no error
        //#endregion
    
        //#region ANIDADO
        Recta r1;
        //Recta.Punto2 p2; //se puede?
        //Recta.Punto p1; //se puede?
        r1 = new Recta(1, 1, "Rojo");
        System.out.println("Color punto 1: " + r1.GetColorP1());
        //#endregion
    
        //#region SIN HERENCIA
        inf253.figuras.Cuadrado c1 = new Cuadrado(5, "verde");
        inf253.figuras.Triangulo t1 = new Triangulo(1, 2, 2, "amarillo");
        inf253.figuras.Imprimidor.Imprime(t1);
        inf253.figuras.Imprimidor.Imprime(c1);
        //#endregion

        //#region HERENCIA 1
        inf253.figuras2.Cuadrado c2 = new inf253.figuras2.Cuadrado(5, "verde");
        inf253.figuras2.Triangulo t2 = new inf253.figuras2.Triangulo(1, 2, 2, "amarillo");
        inf253.figuras2.Figura f2 = new inf253.figuras2.Figura();
        inf253.figuras2.Imprimidor.Imprime(t2);
        inf253.figuras2.Imprimidor.Imprime(c2);
        inf253.figuras2.Imprimidor.Imprime(f2);
        
        inf253.figuras2.Figura f3 = new inf253.figuras2.Cuadrado(10, "arcoiris");
        inf253.figuras2.Imprimidor.Imprime(f3);
        //inf253.figuras2.Triangulo t3 = new inf253.figuras2.Figura(); //esto no!
        //#endregion

        //#region ANOTACIONES HERENCIA
        // -> Constructor
        System.out.println();
        SuperClase sup1 = new SuperClase();
        SuperClase sup2 = new SuperClase(0);
        
        System.out.println();
        SubClase sub1 = new SubClase();
        SubClase sub2 = new SubClase(0);

        System.out.println();
        SuperClase sub3 = new SubClase();
        SuperClase sub4 = new SubClase(0);

        System.out.println();
        SubSubClase ssc1 = new SubSubClase();
        SubSubClase ssc2 = new SubSubClase(0);

        // -> Redefinicion de métodos

        System.out.println();
        System.out.println("-> " + sup1.Suma());
        System.out.println("~> " + sub1.Suma());
        System.out.println("~> " + sub3.Suma());

        System.out.println();
        sup1.Saludador();
        sub1.Saludador();
        sub3.Saludador();

        // -> "Ocultación" de los campos
        System.out.println();
        System.out.println("-> " + sup1.nombre);
        System.out.println("~> " + sub1.nombre);
        System.out.println("~> " + sub3.nombre);

        // -> uso del "super"
        System.out.println();
        System.out.println("~> " + sub1.SuperSUma());
        //System.out.println("~> " + sub3.SuperSUma()); // Ojo con el pcipio de sustitución
        sub1.SuperSaludador();

        // -> Acceso a los metodos
        System.out.println();
        //sup1.Secreto();//esta protegido
        sub1.Secreto();//se hizo publico
        //sub3.Secreto();//Ojo el tipo de la referencia

        //#endregion

        //#region HERENCIA 2: CLASES ABSTRACTAS
        inf253.figuras3.Cuadrado c23 = new inf253.figuras3.Cuadrado(5, "verde");
        inf253.figuras3.Triangulo t23 = new inf253.figuras3.Triangulo(1, 2, 2, "amarillo");
        //inf253.figuras3.Figura f23 = new inf253.figuras3.Figura();
        inf253.figuras3.Imprimidor.Imprime(t23);
        inf253.figuras3.Imprimidor.Imprime(c23);
        //inf253.figuras3.Imprimidor.Imprime(f23);
        
        inf253.figuras3.Figura f33 = new inf253.figuras3.Cuadrado(10, "arcoiris");
        inf253.figuras3.Imprimidor.Imprime(f33);
        //#endregion
    }
}

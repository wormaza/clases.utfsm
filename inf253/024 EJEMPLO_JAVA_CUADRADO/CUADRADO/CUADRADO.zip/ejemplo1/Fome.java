package ejemplo1;

public class Fome {
    int Numero1 = 1;
    public int Numero2 = 2;

    void HolaMundo1(){
        System.out.println("Hola from 1");
    }

    public void HolaMundo2(){
        System.out.println("Hola from 2");
    }
}
